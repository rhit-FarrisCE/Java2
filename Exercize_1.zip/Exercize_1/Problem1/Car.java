public class Car extends Vehicle {
    int numberOfSeats;
    boolean airConditionOn;

    public Car (String modelName, String company, String owner, String engineType, double tankSize, double fuelConsumption, int numberOfSeats){
        super(modelName, company, owner, engineType, tankSize, fuelConsumption);
        this.numberOfSeats = numberOfSeats;
        this.airConditionOn = false;
    }

    public void setNumberOfSeat(int seats){
        this.numberOfSeats = seats;
    }

    public String toString(){
        return "ModelName: " + modelName + ", Company: " + company + ", Owner: " + owner + ", EngineType: " + engineType + ", TankSize: " + tankSize + ", FuelConsumption: " + fuelConsumption + ", NumberOfSeats: " + numberOfSeats;
    }

    public double movableDistance(){
        return tankSize * fuelConsumption;
    }


    @Override
    double costFor100Km(PetroleumPrice pp) {
        return pp.getGasolineCost(100.0 / fuelConsumption);
    }

    @Override
    void setAirConditionON() {
        if(!airConditionOn){
            airConditionOn = true;
            fuelConsumption *= 0.85; 
        }
    }

    @Override
    void setAirConditionOFF() {
        if(airConditionOn){
            airConditionOn = false;
            fuelConsumption /= 0.85; 
        }
    }
}